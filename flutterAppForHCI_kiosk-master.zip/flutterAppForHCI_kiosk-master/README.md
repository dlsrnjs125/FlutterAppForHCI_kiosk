# HCI 프로젝트 : 디지털취약계층 키오스크 UI 만들기
# 팀원 : 황인권 원성혁 윤병욱

flutter project for HCI

## 역할분배

원성혁: start 화면, home 화면
윤병욱: detail 화면
황인권: final 화면

예정: firebase 연동, nevigation 탑제로 화면전환
