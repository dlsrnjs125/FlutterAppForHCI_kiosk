package com.example.flutter_application_kiosk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
